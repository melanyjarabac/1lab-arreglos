/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arreglos.java;

/**
 *
 * @author ESTUDIANTES
 */
public class ArreglosJava {

    public static void main(String[] args) {
       int[]  numeros = {10,20,30,40,50};
       numeros[0]=202;
       
       for (int i = 0;i < numeros.length;i++ )
           System.out.println("posicion"+ i + ":"  + numeros [1]);
       
       //numeros.length
       
        System.out.println("recorrido con for");
        
        for (int num: numeros){
            System.out.println(num);
        }
        
        System.out.println( numeros.length);
       System.out.println( "El arreglo inicia en:"+numeros[0]);
       System.out.println( numeros [0]);
       int[][]matriz={
           {1,2,3},
           {4,5,6},
           {7,8,9},
       };
        System.out.println(matriz [1] [1]);
        for (int i = 0; i< matriz.length; i++){
        for (int j =0; j<matriz[i].length; j++){
         System.out.println(matriz [i] [j] + " ");   
        }
    }
    }
    
    
}
