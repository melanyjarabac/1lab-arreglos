
package com.mycompany.arrayclase;

public class Arrayclase {

    public static void main(String[] args) {
        int[] numeros = {10,20,30,40,50};
        numeros[0]= 202;
        for (int pepapig = 0; < numeros.length;pepapig ++ )
        //numeros.length
        System.out.println(numeros.length);
        
        int[][]matriz = {
            {1,2,3},
            {4,5,6},
            {7,8,9}
        
        };
    }