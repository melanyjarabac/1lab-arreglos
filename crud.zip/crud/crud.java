package com.mycompany.gestordeproductos_crud;
import java.util.Scanner; 

public class Gestordeproductos_CRUD {
    
    static String[] nombres = new String[5]; 
    static double[] precios = new double[5]; 
    static int contador = 0; 

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int opcion; 
        
        do {
            
            System.out.println("------Menu de la empresa productos------\n");
            System.out.println("1. Agregar (create) ");
            System.out.println("2. Listar "); 
            System.out.println("3. Actualizar ");
            System.out.println("4. Eliminar ");
            System.out.println("0. Salir ");
            System.out.println("Seleccione una opcion ");
            
            opcion = sc.nextInt(); 
            sc.nextLine(); 
            
            switch(opcion){
                case 1 -> {
                    System.out.println("Nombre del producto: ");
                    String nombre = sc.nextLine(); 
                    
                    System.out.println("Precio del producto: ");
                    double precio = sc.nextDouble();
                    
                    agregar(nombre, precio); 
                }
                
                case 2 -> {
                    Listar(); 
                }
                
                case 3 -> {
                    if (contador == 0) {
                        System.out.println("No hay productos para actualizar.");
                    } else {
                        Listar();
                        
                        System.out.println("Ingrese la posicion del producto a actualizar: ");
                        int pos = sc.nextInt();
                        sc.nextLine();

                        if (pos >= 0 && pos < contador) {
                            System.out.println("Nuevo nombre del producto: ");
                            String nuevoNombre = sc.nextLine();

                            System.out.println("Nuevo precio del producto: ");
                            double nuevoPrecio = sc.nextDouble();

                            actualizar(pos, nuevoNombre, nuevoPrecio);
                        } else {
                            System.out.println("Posicion invalida.");
                        }
                    }
                }

                case 4 -> {
                    if (contador == 0) {
                        System.out.println("No hay productos para eliminar.");
                    } else {
                        Listar();
                        
                        System.out.println("Ingrese la posicion del producto a eliminar: ");
                        int pos = sc.nextInt();
                        sc.nextLine();

                        eliminar(pos);
                    }
                }
            }
            
        } while(opcion != 0); 
        
        sc.close();
    }

    static boolean agregar(String nombre, double precio){
        if (contador >= nombres.length){
            System.out.println("no hay espacio en el ven¿ctor para almacenar mas elementos : ");
            return false;
        }
        nombres[contador] = nombre; 
        precios[contador] = precio; 
        contador++; 
        return true; 
    }

    static void Listar(){
        if (contador == 0 ){
            System.out.println("No hay productos registrados: ");
            return; 
        }
        
        for(int i = 0; i < contador; i++){
            System.out.println(i + " " + nombres[i]+ " -$ " + precios[i] );
        }
    }

    static boolean actualizar(int posicion, String nuevoNombre, double nuevoPrecio) {
        if (contador == 0) {
            System.out.println("No hay productos para actualizar.");
            return false;
        }

        if (posicion < 0 || posicion >= contador) {
            System.out.println("Posicion invalida.");
            return false;
        }

        nombres[posicion] = nuevoNombre;
        precios[posicion] = nuevoPrecio;
        System.out.println("Producto actualizado correctamente.");
        return true;
    }

    static boolean eliminar(int posicion) {
        if (contador == 0) {
            System.out.println("No hay productos para eliminar.");
            return false;
        }

        if (posicion < 0 || posicion >= contador) {
            System.out.println("Posicion invalida.");
            return false;
        }

        for (int i = posicion; i < contador - 1; i++) {
            nombres[i] = nombres[i + 1];
            precios[i] = precios[i + 1];
        }

        nombres[contador - 1] = null;
        precios[contador - 1] = 0;
        contador--;

        System.out.println("Producto eliminado correctamente.");
        return true;
    }
}